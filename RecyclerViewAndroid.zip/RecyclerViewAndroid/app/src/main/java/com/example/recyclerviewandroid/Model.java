package com.example.recyclerviewandroid;

public class Model {

    private String Name;
    private String Number;
    private String Location;
    private int image;

    public Model() {
    }

    public Model(String name, String number, String location, int image) {
        Name = name;
        Number = number;
        Location = location;
        this.image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
