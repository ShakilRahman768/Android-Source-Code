package com.example.recyclerviewandroid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Model> modellist;
    RecyclerView recyclerView;
    Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        modellist = new ArrayList<>();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter(modellist);
        recyclerView.setAdapter(adapter);

        AddData();

        adapter.notifyDataSetChanged();

    }

    private void AddData() {

        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
        modellist.add(new Model("Shakil","0184305","Dhaka",R.drawable.image));
    }
}